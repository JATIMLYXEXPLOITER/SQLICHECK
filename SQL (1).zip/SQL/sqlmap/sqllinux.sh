#!/bin/bash

# Menampilkan banner
display_banner() {
    echo "===================================="
    echo "     Selamat datang di Sqlmap Mode   "
    echo "===================================="
    echo
}

# Menjalankan skrip Python atau mode SQLmap sesuai input pengguna
execute_command() {
    local command=$1
    echo "Menjalankan perintah: $command"
    eval "$command"
}

# Meminta input angka dari pengguna
read -p "Pilih opsi:
1. Jalankan script proxy.py
2. Jalankan script proxy.py untuk mode 2
3. Jalankan mode SQLmap dengan URL
Masukkan angka: " angka

case $angka in
    1)
        echo "Menjalankan script proxy.py..."
        execute_command "python /prox/proxy.py"
        ;;
    2)
        echo "Menjalankan script proxy.py untuk mode 2..."
        execute_command "python /prox/proxy.py mode2"
        ;;
    3)
        read -p "Masukkan URL: " url
        sqlmap_command="sqlmap -u \"$url\" --batch"
        echo "Menjalankan mode SQLmap dengan URL: $url"
        execute_command "$sqlmap_command"
        ;;
    *)
        echo "Anda memasukkan angka yang tidak valid."
        ;;
esac