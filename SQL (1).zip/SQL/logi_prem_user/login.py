import json
import requests

# Fungsi untuk memuat username dan password dari file teks di GitHub
def load_credentials_from_github(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            credentials = {}
            lines = response.text.split('\n')
            for line in lines:
                if line.strip():  # Melewatkan baris kosong
                    username, password = line.strip().split(',')
                    credentials[username] = password
            return credentials
        else:
            print("Gagal memuat credentials:", response.status_code)
            return None
    except Exception as e:
        print("Error:", e)
        return None

# Fungsi untuk menyimpan data login ke dalam berkas JSON
def save_login_data(username):
    try:
        data = {'username': username}
        with open('./repo/fromlog.json', 'w') as file:
            json.dump(data, file)
        print("Data login berhasil disimpan.")
    except Exception as e:
        print("Error saat menyimpan data login:", e)

# Fungsi login dengan memeriksa username dan password dari credentials
def login(credentials):
    username = input("Masukkan username: ")
    password = input("Masukkan password: ")

    # Periksa apakah username ada dalam credentials dan cocok dengan password yang sesuai
    if username in credentials and credentials[username] == password:
        print("Login berhasil!")
        save_login_data(username)  # Simpan data login
        return True
    else:
        print("Username atau password salah.")
        return False

# Program utama
def main():
    github_url = 'https://raw.githubusercontent.com/Ikkyyylove/login/main/credentials.txt'
    credentials = load_credentials_from_github(github_url)

    if credentials:
        print("Credentials berhasil dimuat dari GitHub:")
        print(credentials)
    else:
        print("Gagal memuat credentials dari GitHub.")

    if credentials:
        login_attempts = 0
        max_attempts = 3
        
        while login_attempts < max_attempts:
            if login(credentials):
                break
            else:
                login_attempts += 1
                print("Sisa percobaan login:", max_attempts - login_attempts)
        else:
            print("Anda telah melebihi batas percobaan login. Akun Anda diblokir.")

if __name__ == "__main__":
    main()