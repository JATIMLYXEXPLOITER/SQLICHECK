import requests
import time

def load_admin_pages_from_github(url):
    response = requests.get(url)
    if response.status_code == 200:
        admin_pages = response.text.split("\n")
        return admin_pages
    else:
        print("Gagal memuat daftar admin pages dari Database")
        return []

def find_admin_pages(url, admin_pages):
    admin_pages_found = []
    total_pages = len(admin_pages)
    for i, page in enumerate(admin_pages, start=1):
        admin_url = url + "/" + page.strip()
        response = requests.get(admin_url)
        if response.status_code == 200:
            admin_pages_found.append(admin_url)
        print(f"[\/] Sedang melakukan pencarian dari {i}/{total_pages}", end="\r")
        time.sleep(0.5)  # Menunggu 0.5 detik sebelum pencarian berikutnya
    print()  # Pindahkan cursor ke baris baru setelah selesai pencarian
    return admin_pages_found

def main():
    target_url = input("Masukkan URL target: ")
    github_admin_list_url = "https://raw.githubusercontent.com/the-robot/admin-finder/master/wordlist.txt"
    admin_pages = load_admin_pages_from_github(github_admin_list_url)
    
    if admin_pages:
        print("Daftar admin pages berhasil dimuat dari Database Server.")
        print("Mencari halaman admin...")
        admin_pages_found = find_admin_pages(target_url, admin_pages)
        
        if admin_pages_found:
            print("Halaman admin ditemukan:")
            for page in admin_pages_found:
                print(page)
        else:
            print("Tidak ditemukan halaman admin.")
    else:
        print("Gagal memuat daftar admin pages.")

if __name__ == "__main__":
    main()
